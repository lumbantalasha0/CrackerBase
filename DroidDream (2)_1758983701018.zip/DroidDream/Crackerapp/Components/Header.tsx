import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import theme from '../lib/theme';

export default function Header({ title, right }: { title: string; right?: React.ReactNode }) {
  return (
    <View style={styles.container}>
      <Text style={styles.title}>{title}</Text>
      <View style={styles.right}>{right}</View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    paddingHorizontal: theme.spacing.md,
    paddingVertical: theme.spacing.sm,
    backgroundColor: theme.colors.background,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  title: {
    fontSize: theme.type.h2,
    color: theme.colors.primaryDark,
    fontFamily: theme.fonts.heading,
  },
  right: {},
});