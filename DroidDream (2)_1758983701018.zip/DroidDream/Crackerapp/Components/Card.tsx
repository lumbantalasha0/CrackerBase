import React from 'react';
import { View, ViewProps, StyleSheet } from 'react-native';
import theme from '../lib/theme';

type CardProps = ViewProps & {
  leftAccent?: string;
};

export default function Card({ children, style, leftAccent, ...rest }: CardProps) {
  return (
    <View style={[styles.container, leftAccent ? { borderLeftColor: leftAccent, borderLeftWidth: 6 } : {}, style]} {...rest}>
      {children}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: theme.colors.surface,
    borderRadius: theme.radii.lg,
    padding: theme.spacing.md,
    marginBottom: theme.spacing.md,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 6 },
    shadowOpacity: 0.06,
    shadowRadius: 12,
    elevation: 3,
    borderColor: theme.colors.border,
    borderWidth: 1,
  },
});