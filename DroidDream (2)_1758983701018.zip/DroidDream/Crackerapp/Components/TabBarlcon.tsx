import React from 'react';
import { View } from 'react-native';
import { MaterialIcons } from '@expo/vector-icons';
import theme from '../lib/theme';

type Props = {
  name: React.ComponentProps<typeof MaterialIcons>['name'];
  color?: string;
  size?: number;
};

export default function TabBarIcon({ name, color, size = 24 }: Props) {
  return (
    <View style={{ width: 32, alignItems: 'center' }}>
      <MaterialIcons name={name} size={size} color={color ?? theme.colors.muted} />
    </View>
  );
}