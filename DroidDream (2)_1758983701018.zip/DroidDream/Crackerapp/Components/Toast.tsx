// new file: components/Toast.tsx
import React, { createContext, useContext, useState, useCallback } from "react";
import { Animated, Text, View, StyleSheet } from "react-native";
import theme from "../lib/theme";

const ToastContext = createContext<any>(null);

export function ToastProvider({ children }: any) {
  const [toasts, setToasts] = useState<any[]>([]);

  const show = useCallback((message: string, duration = 3000) => {
    const id = Date.now().toString();
    setToasts((t) => [...t, { id, message }]);
    setTimeout(() => setToasts((t) => t.filter((x) => x.id !== id)), duration);
  }, []);

  return (
    <ToastContext.Provider value={{ show }}>
      {children}
      <View pointerEvents="none" style={styles.wrapper}>
        {toasts.map((t) => (
          <View key={t.id} style={styles.toast}>
            <Text style={styles.text}>{t.message}</Text>
          </View>
        ))}
      </View>
    </ToastContext.Provider>
  );
}

export function useToast() {
  return useContext(ToastContext);
}

const styles = StyleSheet.create({
  wrapper: {
    position: "absolute",
    bottom: 40,
    left: 16,
    right: 16,
    alignItems: "center",
  },
  toast: {
    backgroundColor: theme.colors.primaryDark,
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 8,
    marginTop: 8,
    shadowColor: "#000",
    shadowOpacity: 0.12,
    shadowOffset: { width: 0, height: 2 },
    elevation: 3,
  },
  text: { color: "white" },
});
