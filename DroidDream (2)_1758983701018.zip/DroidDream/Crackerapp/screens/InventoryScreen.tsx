// new file screens/InventoryScreen.tsx
import React, { useEffect, useState } from 'react';
import { View, Text, StyleSheet, FlatList, TouchableOpacity, Modal, TextInput, Button, Alert, ScrollView } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { getAvailableStock, listStock, deleteStock, addStock } from '../lib/crackersBackend';
import theme from '../lib/theme';
import layout from '../lib/layout';

export default function InventoryScreen() {
  const [available, setAvailable] = useState<number>(0);
  const [stockList, setStockList] = useState<any[]>([]);
  const [visible, setVisible] = useState(false);
  const [quantity, setQuantity] = useState('');
  const [note, setNote] = useState('');

  useEffect(() => { refresh(); }, []);

  async function refresh() {
    try { const av = await getAvailableStock(); setAvailable(av); } catch (e) { setAvailable(0); }
    try { const stocks = await listStock(); setStockList(stocks); } catch (e) { setStockList([]); }
  }

  async function onSave() {
    const q = Number(quantity);
    if (!q || q <= 0) { Alert.alert('Error', 'Enter valid quantity'); return; }
    const res = await addStock({ quantity: q, date: new Date().toISOString(), note: note || null });
    if (!res.success) Alert.alert('Error', res.message || 'Failed'); else { Alert.alert('Saved', res.message || 'Saved'); setVisible(false); setQuantity(''); setNote(''); refresh(); }
  }

  async function onDeleteStock(item: any) {
    Alert.alert('Confirm', 'Delete this stock entry?', [
      { text: 'Cancel', style: 'cancel' },
      { text: 'Delete', style: 'destructive', onPress: async () => {
          try {
            const r = await deleteStock(item.id);
            if (r.success) { Alert.alert('Deleted', r.message || 'Deleted'); refresh(); } else Alert.alert('Error', r.message || 'Failed');
          } catch (err) { Alert.alert('Error', 'Failed to delete stock'); }
        }
      }
    ]);
  }

  return (
    <SafeAreaView style={styles.container} edges={["top"]}>
      <ScrollView contentContainerStyle={{ flexGrow: 1, paddingTop: layout.secondElementOffset }}>
      <View style={styles.header}>
        <Text style={styles.title}>Crackers Inventory</Text>
        <Text style={styles.subtitle}>Available: {available}</Text>
      </View>

      <View style={styles.content}>
        <TouchableOpacity style={[styles.addBtn, { backgroundColor: theme.colors.primary }]} onPress={() => setVisible(true)}>
          <Text style={styles.addBtnText}>Add Stock</Text>
        </TouchableOpacity>

        <Text style={styles.sectionTitle}>Stock Entries</Text>
        <FlatList
          data={stockList}
          keyExtractor={(i) => String(i.id)}
          renderItem={({ item }) => (
            <View style={styles.row}>
              <View style={{ flex: 1 }}>
                <Text style={styles.rowText}>{item.quantity} pcs</Text>
                <Text style={styles.rowSub}>{(item.date || '').slice(0, 10)} {item.note ? '• ' + item.note : ''}</Text>
              </View>
              <View style={{ flexDirection: 'row' }}>
                <View style={{ width: 90 }}>
                  <Button title="Delete" color={theme.colors.danger} onPress={() => onDeleteStock(item)} />
                </View>
              </View>
            </View>
          )}
        />
      </View>
      </ScrollView>

      <Modal visible={visible} animationType="slide">
        <SafeAreaView style={styles.modal}>
          <Text style={styles.modalTitle}>Add Crackers Stock</Text>
          <TextInput placeholder="Quantity" keyboardType="number-pad" style={styles.input} value={quantity} onChangeText={setQuantity} />
          <TextInput placeholder="Note (optional)" style={styles.input} value={note} onChangeText={setNote} />
          <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
            <View style={{ flex: 1, marginRight: 8 }}><Button title="Cancel" onPress={() => setVisible(false)} /></View>
            <View style={{ flex: 1, marginLeft: 8 }}><Button title="Save" onPress={onSave} /></View>
          </View>
        </SafeAreaView>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: theme.colors.background },
  header: { padding: 8, borderBottomColor: theme.colors.border, borderBottomWidth: 1 },
  title: { fontSize: 20, fontWeight: '700', color: theme.colors.primaryDark },
  subtitle: { marginTop: 4, color: theme.colors.textSecondary },
  content: { padding: 16 },
  addBtn: { padding: 12, borderRadius: 8, alignItems: 'center' },
  addBtnText: { color: 'white', fontWeight: '700' },
  sectionTitle: { marginTop: 16, marginBottom: 8, fontSize: 16, fontWeight: '600' },
  row: { padding: 12, backgroundColor: theme.colors.surface, borderRadius: 8, marginBottom: 8, flexDirection: 'row', alignItems: 'center' },
  rowText: { fontWeight: '600', color: theme.colors.textPrimary },
  rowSub: { color: theme.colors.textSecondary, marginTop: 4 },
  modal: { flex: 1, padding: 16, backgroundColor: theme.colors.background },
  modalTitle: { fontSize: 18, fontWeight: '700', marginBottom: 12, color: theme.colors.primaryDark },
  input: { borderWidth: 1, borderColor: theme.colors.border, padding: 12, borderRadius: 8, marginBottom: 12, backgroundColor: theme.colors.surface }
});