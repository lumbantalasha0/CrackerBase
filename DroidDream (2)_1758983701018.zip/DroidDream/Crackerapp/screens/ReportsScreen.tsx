// new file screens/ReportsScreen.tsx
import React, { useEffect, useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  Button,
  Alert,
  TouchableOpacity,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import {
  totalSales,
  totalExpenses,
  topCustomers,
  salesOverTime,
  exportAllToPDF,
  getAvailableStock,
} from "../lib/crackersBackend";
import theme from "../lib/theme";
import { useToast } from "../components/Toast";
import api from "../lib/api";
import layout from "../lib/layout";

// Defensive import for chart-kit
let Chart: any = null;
try {
  // eslint-disable-next-line @typescript-eslint/no-var-requires
  Chart = require("react-native-chart-kit");
} catch (e) {
  Chart = null;
}

export default function ReportsScreen({ navigation }: any) {
  const toast = useToast();
  const [salesTotal, setSalesTotal] = useState(0);
  const [expensesTotal, setExpensesTotal] = useState(0);
  const [profit, setProfit] = useState(0);
  const [top, setTop] = useState<any[]>([]);
  const [stockAvail, setStockAvail] = useState(0);
  const [salesSeries, setSalesSeries] = useState<any[]>([]);

  useEffect(() => {
    refresh();
  }, []);

  async function refresh() {
    const s = await totalSales();
    setSalesTotal(s);
    const e = await totalExpenses();
    setExpensesTotal(e);
    setProfit(s - e);
    const t = await topCustomers();
    setTop(t);
    const av = await getAvailableStock();
    setStockAvail(av);
    const end = new Date();
    const start = new Date();
    start.setDate(end.getDate() - 29);
    const data = await salesOverTime({
      start: start.toISOString(),
      end: end.toISOString(),
    });
    setSalesSeries(data);
  }

  async function onExportPDF() {
    const res = await exportAllToPDF();
    if (!res.success) toast.show(res.message || "PDF export failed");
    else {
      toast.show("PDF exported");
    }
  }

  async function onUploadPDF() {
    const res = await exportAllToPDF();
    if (!res.success) {
      toast.show(res.message || "PDF generation failed");
      return;
    }
    const uri = res.uri;
    // Try server upload
    const serverRes = await api.uploadPdfToServer(uri, "bntalasha@gmail.com");
    if (serverRes && serverRes.success) {
      toast.show("Uploaded to server and emailed.");
      return;
    }
    // fallback to MailComposer
    let MailComposer: any = null;
    try {
      MailComposer = require("expo-mail-composer");
    } catch (e) {
      MailComposer = null;
    }
    if (MailComposer && MailComposer.isAvailableAsync) {
      try {
        const avail = await MailComposer.isAvailableAsync();
        if (avail) {
          await MailComposer.composeAsync({
            recipients: ["bntalasha@gmail.com"],
            subject: "BEMACHO Monthly Report",
            body: "Please find attached the report.",
            attachments: [uri],
          });
          toast.show("Email composer opened with attachment.");
          return;
        }
      } catch (e) {
        /* fallback */
      }
    }
    let Sharing: any = null;
    try {
      Sharing = require("expo-sharing");
    } catch (e) {
      Sharing = null;
    }
    if (Sharing && Sharing.isAvailableAsync) {
      try {
        await Sharing.shareAsync(uri);
        toast.show("Share dialog opened");
        return;
      } catch (e) {
        /* ignore */
      }
    }
    const subject = encodeURIComponent("BEMACHO Monthly Report");
    const body = encodeURIComponent(
      "Please find the attached report (sent separately).",
    );
    const mailto = `mailto:bntalasha@gmail.com?subject=${subject}&body=${body}`;
    try {
      const Linking = require("react-native").Linking;
      Linking.openURL(mailto);
      toast.show("Opened mail client. Please attach the report manually.");
    } catch (e) {
      toast.show("Unable to open mail client.");
    }
  }

  return (
    <SafeAreaView style={styles.container}>
      <View style={[styles.headerRow, { paddingTop: 8 }]}>
        <Text style={[styles.title, { color: theme.colors.primaryDark }]}>
          Reports
        </Text>
        <View style={{ flexDirection: "row" }}>
          <TouchableOpacity style={styles.headerButton} onPress={onExportPDF}>
            <Text style={{ color: "#fff" }}>Export PDF</Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={[
              styles.headerButton,
              { backgroundColor: theme.colors.muted, marginLeft: 8 },
            ]}
            onPress={onUploadPDF}
          >
            <Text style={{ color: "#fff" }}>Upload to Email</Text>
          </TouchableOpacity>
        </View>
      </View>
      <ScrollView
        contentContainerStyle={[
          styles.content,
          { paddingTop: layout.secondElementOffset },
        ]}
      >
        <View style={[styles.card, { borderLeftColor: theme.colors.primary }]}>
          <Text style={styles.cardTitle}>Summary</Text>
          <Text>
            Total Sales: {theme.currency.symbol}
            {Number(salesTotal).toLocaleString()}
          </Text>
          <Text>
            Total Expenses: {theme.currency.symbol}
            {Number(expensesTotal).toLocaleString()}
          </Text>
          <Text>
            Net Profit: {theme.currency.symbol}
            {Number(profit).toLocaleString()}
          </Text>
          <Text>Stock remaining: {stockAvail}</Text>
        </View>

        <View style={[styles.card, { borderLeftColor: theme.colors.accent }]}>
          <Text style={styles.cardTitle}>Top Customers</Text>
          {top.length === 0 ? (
            <Text>No customers</Text>
          ) : (
            top.map((c) => (
              <Text key={c.id}>
                {c.name} — {c.total_quantity} pcs
              </Text>
            ))
          )}
        </View>

        <View style={[styles.card, { borderLeftColor: theme.colors.muted }]}>
          <Text style={styles.cardTitle}>Sales Over Time (30 days)</Text>
          {Chart && salesSeries.length > 0 ? (
            <Chart.LineChart
              data={{
                labels: salesSeries.map((s) => s.day.slice(5)),
                datasets: [{ data: salesSeries.map((s) => s.sales) }],
              }}
              width={300}
              height={160}
              chartConfig={{
                backgroundGradientFrom: "#fff",
                backgroundGradientTo: "#fff",
                color: () => theme.colors.primary,
                labelColor: () => theme.colors.textSecondary,
              }}
              bezier
              style={{ borderRadius: 8 }}
            />
          ) : (
            <Text>
              Chart library not installed or no data — salesOverTime() returns
              data you can plot.
            </Text>
          )}
        </View>

        <View style={[styles.card, { borderLeftColor: theme.colors.muted }]}>
          <Text style={styles.cardTitle}>About</Text>
          <Text style={{ marginTop: 8 }}>Property of BEMACHO 2007 - 2025</Text>
          <Text style={{ marginTop: 4 }}>LumbaNtalasha@2025</Text>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: theme.colors.background },
  headerRow: {
    padding: 12,
    borderBottomColor: theme.colors.border,
    borderBottomWidth: 1,
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },
  title: { fontSize: 20, fontWeight: "700" },
  headerButton: {
    backgroundColor: theme.colors.primaryDark,
    paddingVertical: 8,
    paddingHorizontal: 12,
    borderRadius: 8,
  },
  content: { padding: 16 },
  card: {
    backgroundColor: theme.colors.surface,
    borderRadius: 8,
    padding: 12,
    marginBottom: 12,
    borderLeftWidth: 4,
  },
  cardTitle: { fontWeight: "700", marginBottom: 8 },
});
