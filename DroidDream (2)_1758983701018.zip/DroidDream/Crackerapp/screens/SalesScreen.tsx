// new file screens/SalesScreen.tsx
import React, { useEffect, useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  TouchableOpacity,
  Modal,
  TextInput,
  Button,
  Alert,
  ScrollView,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import {
  listSales,
  saveSale,
  editSale,
  deleteSale,
  listCustomers,
  addCustomer,
  getAvailableStock,
} from "../lib/crackersBackend";
import theme from "../lib/theme";
import layout from "../lib/layout";

export default function SalesScreen() {
  const [sales, setSales] = useState<any[]>([]);
  const [customers, setCustomers] = useState<any[]>([]);
  const [visible, setVisible] = useState(false);
  const [editing, setEditing] = useState<any | null>(null);
  const [customerId, setCustomerId] = useState<number | null>(null);
  const [newCustomerName, setNewCustomerName] = useState("");
  const [newCustomerPhone, setNewCustomerPhone] = useState("");
  const [newCustomerCompany, setNewCustomerCompany] = useState("");
  const [quantity, setQuantity] = useState("");
  const [price, setPrice] = useState("");

  useEffect(() => {
    refresh();
  }, []);

  async function refresh() {
    try {
      const s = await listSales();
      setSales(s);
    } catch (e) {
      setSales([]);
    }
    try {
      const c = await listCustomers();
      setCustomers(c);
    } catch (e) {
      setCustomers([]);
    }
  }

  async function openNew() {
    const avail = await getAvailableStock();
    if (avail <= 0) {
      Alert.alert(
        "Stock Finished",
        "No crackers available. Please add stock before recording sales.",
      );
      return;
    }
    setEditing(null);
    setCustomerId(null);
    setQuantity("");
    setPrice("");
    setVisible(true);
  }

  async function onSave() {
    const q = Number(quantity);
    const p = Number(price);
    if (!q || q <= 0) {
      Alert.alert("Error", "Enter valid quantity");
      return;
    }
    if (!p || p <= 0) {
      Alert.alert("Error", "Enter valid price");
      return;
    }
    let cid = customerId;
    try {
      if (!cid && newCustomerName.trim()) {
        const r = await addCustomer({
          name: newCustomerName.trim(),
          phone: newCustomerPhone.trim() || null,
          business_name: newCustomerCompany.trim() || null,
        });
        if (!r.success) {
          Alert.alert("Error", r.message || "Failed to add customer");
          return;
        }
        cid = r.id;
        if (!cid) {
          const cList = await listCustomers();
          setCustomers(cList);
          const found = cList.find(
            (c) =>
              c.name === newCustomerName.trim() &&
              (newCustomerPhone.trim()
                ? c.phone === newCustomerPhone.trim()
                : true),
          );
          if (found) cid = found.id;
        }
      }

      let res;
      if (editing) {
        res = await editSale({
          id: editing.id,
          customerId: cid,
          quantity: q,
          pricePerUnit: p,
          date: new Date().toISOString(),
          note: null,
        });
      } else {
        res = await saveSale({
          customerId: cid,
          quantity: q,
          pricePerUnit: p,
          date: new Date().toISOString(),
          note: null,
        });
      }

      if (!res || !res.success) {
        Alert.alert("Error", (res && res.message) || "Failed to save sale");
        return;
      }

      Alert.alert("Saved", res.message || "Saved");
      setVisible(false);
      setNewCustomerName("");
      setNewCustomerPhone("");
      setNewCustomerCompany("");
      await refresh();
    } catch (err: any) {
      Alert.alert("Error", err && err.message ? err.message : String(err));
    }
  }

  async function onDelete(item: any) {
    Alert.alert("Confirm", "Delete this sale?", [
      { text: "Cancel", style: "cancel" },
      {
        text: "Delete",
        style: "destructive",
        onPress: async () => {
          const r = await deleteSale(item.id);
          if (r.success) {
            Alert.alert("Deleted", r.message || "Deleted");
            refresh();
          } else Alert.alert("Error", r.message || "Failed");
        },
      },
    ]);
  }

  async function onEdit(item: any) {
    setEditing(item);
    setCustomerId(item.customer_id);
    setQuantity(String(item.quantity));
    setPrice(String(item.price_per_unit));
    setVisible(true);
  }

  return (
    <SafeAreaView style={styles.container} edges={["top"]}>
      <View style={styles.header}>
        <Text style={styles.title}>Sales</Text>
      </View>
      <ScrollView
        contentContainerStyle={[
          styles.content,
          { paddingTop: layout.secondElementOffset },
        ]}
      >
        <TouchableOpacity
          style={[styles.addBtn, { backgroundColor: theme.colors.primary }]}
          onPress={openNew}
        >
          <Text style={styles.addBtnText}>Record Sale</Text>
        </TouchableOpacity>
        <FlatList
          data={sales}
          keyExtractor={(i) => String(i.id)}
          renderItem={({ item }) => (
            <View style={styles.row}>
              <View>
                <Text style={styles.rowText}>
                  {item.quantity} pcs — {item.total_price} ZMW
                </Text>
                <Text style={styles.rowSub}>
                  {(item.date || "").slice(0, 10)} • Customer ID:{" "}
                  {item.customer_id || "Walk-in"}
                </Text>
              </View>
              <View style={{ flexDirection: "row" }}>
                <View style={{ width: 70, marginRight: 8 }}>
                  <Button title="Edit" onPress={() => onEdit(item)} />
                </View>
                <View style={{ width: 90 }}>
                  <Button
                    title="Delete"
                    color={theme.colors.danger}
                    onPress={() => onDelete(item)}
                  />
                </View>
              </View>
            </View>
          )}
        />
      </ScrollView>

      <Modal visible={visible} animationType="slide">
        <SafeAreaView style={styles.modal} edges={["top"]}>
          <Text style={styles.modalTitle}>
            {editing ? "Edit Sale" : "Record Sale"}
          </Text>
          <Text style={{ marginBottom: 6 }}>Customer (select or add new):</Text>
          <View
            style={{
              borderWidth: 1,
              borderColor: "#ddd",
              borderRadius: 8,
              marginBottom: 12,
            }}
          >
            <FlatList
              horizontal
              data={customers}
              keyExtractor={(c) => String(c.id)}
              renderItem={({ item }) => (
                <TouchableOpacity
                  style={[
                    styles.chip,
                    customerId === item.id && {
                      backgroundColor: theme.colors.primary,
                    },
                  ]}
                  onPress={() => setCustomerId(item.id)}
                >
                  <Text
                    style={{
                      color:
                        customerId === item.id
                          ? "white"
                          : theme.colors.textPrimary,
                    }}
                  >
                    {item.name}
                  </Text>
                </TouchableOpacity>
              )}
            />
          </View>
          <Text style={{ marginBottom: 6 }}>Or add new customer:</Text>
          <TextInput
            placeholder="Name"
            style={styles.input}
            value={newCustomerName}
            onChangeText={setNewCustomerName}
          />
          <TextInput
            placeholder="Phone number"
            keyboardType="phone-pad"
            style={styles.input}
            value={newCustomerPhone}
            onChangeText={setNewCustomerPhone}
          />
          <TextInput
            placeholder="Company / Business Name"
            style={styles.input}
            value={newCustomerCompany}
            onChangeText={setNewCustomerCompany}
          />
          <TextInput
            placeholder="Quantity"
            keyboardType="number-pad"
            style={styles.input}
            value={quantity}
            onChangeText={setQuantity}
          />
          <TextInput
            placeholder="Price per unit (ZMW)"
            keyboardType="decimal-pad"
            style={styles.input}
            value={price}
            onChangeText={setPrice}
          />
          <View
            style={{ flexDirection: "row", justifyContent: "space-between" }}
          >
            <View style={{ flex: 1, marginRight: 8 }}>
              <Button title="Cancel" onPress={() => setVisible(false)} />
            </View>
            <View style={{ flex: 1, marginLeft: 8 }}>
              <Button title="Save" onPress={onSave} />
            </View>
          </View>
        </SafeAreaView>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: theme.colors.background },
  header: {
    padding: 8,
    borderBottomColor: theme.colors.border,
    borderBottomWidth: 1,
  },
  title: { fontSize: 20, fontWeight: "700", color: theme.colors.primaryDark },
  content: { padding: 12, paddingBottom: 48 },
  addBtn: {
    padding: 12,
    borderRadius: 8,
    alignItems: "center",
    marginBottom: 12,
  },
  addBtnText: { color: "white", fontWeight: "700" },
  row: {
    padding: 12,
    backgroundColor: theme.colors.surface,
    borderRadius: 8,
    marginBottom: 8,
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },
  rowText: { fontWeight: "600", color: theme.colors.textPrimary },
  rowSub: { color: theme.colors.textSecondary, marginTop: 4 },
  modal: { flex: 1, padding: 16, backgroundColor: theme.colors.background },
  modalTitle: {
    fontSize: 18,
    fontWeight: "700",
    marginBottom: 12,
    color: theme.colors.primaryDark,
  },
  input: {
    borderWidth: 1,
    borderColor: theme.colors.border,
    padding: 12,
    borderRadius: 8,
    marginBottom: 12,
    backgroundColor: theme.colors.surface,
  },
  chip: {
    padding: 8,
    borderRadius: 16,
    borderWidth: 1,
    borderColor: theme.colors.border,
    marginRight: 8,
  },
});
