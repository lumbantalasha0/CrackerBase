// new file screens/SettingsScreen.tsx
import React, { useEffect, useState } from 'react';
import { View, Text, StyleSheet, FlatList, TouchableOpacity, Modal, TextInput, Alert, ScrollView } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { listCustomers, addCustomer, deleteCustomer, listExpenseTypes, addExpenseType, deleteExpenseType, getIngredientUnits, setIngredientUnit, exportAllToPDF } from '../lib/crackersBackend';
import theme from '../lib/theme';
import Card from '../components/Card';
import Button from '../components/Button';

export default function SettingsScreen() {
  const [customers, setCustomers] = useState<any[]>([]);
  const [expenseTypes, setExpenseTypes] = useState<any[]>([]);
  const [ingredientUnits, setIngredientUnits] = useState<any>({});
  const [showAddCustomer, setShowAddCustomer] = useState(false);
  const [newName, setNewName] = useState('');
  const [newPhone, setNewPhone] = useState('');
  const [newCompany, setNewCompany] = useState('');
  const [newLocation, setNewLocation] = useState('');
  const [newExpenseType, setNewExpenseType] = useState('');
  const [newIngredient, setNewIngredient] = useState('');
  const [newMultiplier, setNewMultiplier] = useState('');

  useEffect(()=>{ refresh(); loadPin(); }, []);
  async function refresh() {
    try { const c = await listCustomers(); setCustomers(c); } catch (e) { setCustomers([]); }
    try { const et = await listExpenseTypes(); setExpenseTypes(et); } catch (e) { setExpenseTypes([]); }
    try { const iu = await getIngredientUnits(); setIngredientUnits(iu); } catch (e) { setIngredientUnits({}); }
  }

  // PIN management
  const [pin, setPin] = useState('');
  const [editingPin, setEditingPin] = useState(false);
  async function loadPin() {
    try { const p = await (require('../lib/crackersBackend').getSetting)('pin', '4207'); setPin(String(p || '4207')); } catch (e) { setPin('4207'); }
  }
  async function savePin() {
    try {
      const set = await (require('../lib/crackersBackend').setSetting)('pin', pin || '4207');
      if (set && set.success) { Alert.alert('Saved','PIN updated'); setEditingPin(false); } else { Alert.alert('Error','Failed to save PIN'); }
    } catch (e) { Alert.alert('Error','Failed to save PIN'); }
  }

  async function onAddCustomer() {
    if (!newName.trim()) { Alert.alert('Error','Name required'); return; }
    const res = await addCustomer({ name: newName.trim(), phone: newPhone.trim() || null, business_name: newCompany.trim() || null, location: newLocation.trim() || null });
    if (!res.success) Alert.alert('Error', res.message || 'Failed'); else { Alert.alert('Saved','Customer added'); setShowAddCustomer(false); setNewName(''); setNewPhone(''); setNewCompany(''); setNewLocation(''); await refresh(); }
  }

  async function onDeleteCustomer(id: number) {
    Alert.alert('Confirm', 'Delete this customer?', [ { text: 'Cancel', style: 'cancel' }, { text: 'Delete', style: 'destructive', onPress: async () => { const r = await deleteCustomer(id); if (!r.success) Alert.alert('Error', r.message || 'Failed'); else { Alert.alert('Deleted', r.message || 'Deleted'); await refresh(); } } } ]);
  }

  async function onAddExpenseType() {
    if (!newExpenseType.trim()) { Alert.alert('Error','Name required'); return; }
    const res = await addExpenseType(newExpenseType.trim());
    if (!res.success) Alert.alert('Error', res.message || 'Failed'); else { Alert.alert('Saved','Expense type added'); setNewExpenseType(''); await refresh(); }
  }

  async function onDeleteExpenseType(id: number) {
    Alert.alert('Confirm', 'Delete this expense type?', [ { text: 'Cancel', style: 'cancel' }, { text: 'Delete', style: 'destructive', onPress: async () => { const r = await deleteExpenseType(id); if (!r.success) Alert.alert('Error', r.message || 'Failed'); else { Alert.alert('Deleted', r.message || 'Deleted'); await refresh(); } } } ]);
  }

  async function onSetIngredient() {
    if (!newIngredient.trim()) { Alert.alert('Error','Ingredient required'); return; }
    const m = Number(newMultiplier);
    if (isNaN(m)) { Alert.alert('Error','Multiplier must be a number'); return; }
    const res = await setIngredientUnit(newIngredient.trim(), m);
    if (!res.success) Alert.alert('Error', res.message || 'Failed'); else { Alert.alert('Saved','Ingredient multiplier saved'); setNewIngredient(''); setNewMultiplier(''); await refresh(); }
  }

  async function onExportAllPDF() {
    const res = await exportAllToPDF();
    if (!res.success) Alert.alert('Error', res.message || 'Export failed'); else Alert.alert('Exported', res.message || res.uri);
  }

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}><Text style={styles.title}>Settings</Text></View>
      <ScrollView contentContainerStyle={styles.content}>
        <Card leftAccent={theme.colors.primary}>
          <Text style={styles.sectionTitle}>Customers</Text>
          <Button title="Add Customer" onPress={()=>setShowAddCustomer(true)} />
          <FlatList data={customers} keyExtractor={(i)=>String(i.id)} renderItem={({item})=> (
            <View style={{ flexDirection: 'row', justifyContent: 'space-between', paddingVertical:6 }}>
              <Text>{item.name} • {item.phone || '-'} • {item.business_name || '-'}</Text>
              <View style={{ width: 90 }}><Button title="Delete" color={theme.colors.danger} onPress={()=>onDeleteCustomer(item.id)} /></View>
            </View>
          )} />
        </Card>

        <Card leftAccent={theme.colors.accent}>
          <Text style={styles.sectionTitle}>Expense Types</Text>
          <FlatList data={expenseTypes} keyExtractor={(i)=>String(i.id)} renderItem={({item})=> (
            <View style={{ flexDirection:'row', justifyContent:'space-between', paddingVertical:6 }}>
              <Text>{item.name}</Text>
              <View style={{ width: 90 }}><Button title="Delete" color={theme.colors.danger} onPress={()=>onDeleteExpenseType(item.id)} /></View>
            </View>
          )} />
          <TextInput placeholder="New expense type" value={newExpenseType} onChangeText={setNewExpenseType} style={styles.input} />
          <Button title="Add Expense Type" onPress={onAddExpenseType} />
        </Card>

        <Card leftAccent={theme.colors.primaryDark}>
          <Text style={styles.sectionTitle}>Ingredient Units (per 1kg flour)</Text>
          {Object.keys(ingredientUnits).map(k => (<Text key={k}>{k}: {ingredientUnits[k]}</Text>))}
          <TextInput placeholder="Ingredient e.g. Salt" value={newIngredient} onChangeText={setNewIngredient} style={styles.input} />
          <TextInput placeholder="Multiplier (e.g. 0.5)" value={newMultiplier} onChangeText={setNewMultiplier} keyboardType='decimal-pad' style={styles.input} />
          <Button title="Set Ingredient" onPress={onSetIngredient} />
        </Card>

        <Card leftAccent={theme.colors.muted}>
          <Text style={styles.sectionTitle}>Export & Backup</Text>
          <Button title="Export PDF (All Data)" onPress={onExportAllPDF} />
        </Card>

        <Card leftAccent={theme.colors.muted}>
          <Text style={styles.sectionTitle}>PIN</Text>
          <Text>Current PIN: {pin}</Text>
          {editingPin ? (
            <View>
              <TextInput value={pin} onChangeText={setPin} style={styles.input} keyboardType='number-pad' />
              <Button title='Save PIN' onPress={savePin} />
            </View>
          ) : (
            <Button title='Change PIN' onPress={()=>setEditingPin(true)} />
          )}
        </Card>

        <Card leftAccent={theme.colors.muted}>
          <Text style={styles.sectionTitle}>About</Text>
          <Text style={{ marginTop: 8 }}>Property of BEMACHO 2007 - 2025</Text>
          <Text style={{ marginTop: 4 }}>LumbaNtalasha@2025</Text>
        </Card>
      </ScrollView>

      <Modal visible={showAddCustomer} animationType='slide'>
        <SafeAreaView style={{ flex:1, padding:16 }}>
          <Text style={{ fontSize:18, fontWeight:'700', marginBottom:12 }}>Add Customer</Text>
          <TextInput placeholder='Name' value={newName} onChangeText={setNewName} style={styles.input} />
          <TextInput placeholder='Phone' value={newPhone} onChangeText={setNewPhone} style={styles.input} keyboardType='phone-pad' />
          <TextInput placeholder='Company' value={newCompany} onChangeText={setNewCompany} style={styles.input} />
          <TextInput placeholder='Location' value={newLocation} onChangeText={setNewLocation} style={styles.input} />
          <View style={{ flexDirection:'row', justifyContent:'space-between' }}>
            <View style={{ flex:1, marginRight:8 }}><Button title='Cancel' onPress={()=>setShowAddCustomer(false)} /></View>
            <View style={{ flex:1, marginLeft:8 }}><Button title='Save' onPress={onAddCustomer} /></View>
          </View>
        </SafeAreaView>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex:1, backgroundColor: theme.colors.background },
  header: { padding:8, borderBottomColor: theme.colors.border, borderBottomWidth:1 },
  title: { fontSize:20, fontWeight:'700', color: theme.colors.primaryDark, textAlign:'left' },
  content: { padding:12, paddingBottom: 40 },
  sectionTitle: { fontWeight:'700', marginBottom:8 },
  input: { borderWidth:1, borderColor: theme.colors.border, padding:12, borderRadius:8, marginBottom:8, backgroundColor: theme.colors.surface }
});