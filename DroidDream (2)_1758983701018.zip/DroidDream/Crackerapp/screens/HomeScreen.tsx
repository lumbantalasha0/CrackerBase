import React, { useEffect, useState } from "react";
import { ScrollView, View, Text, StyleSheet } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import theme from "../lib/theme";
import layout from "../lib/layout";
import Card from "../components/Card";
import Button from "../components/Button";
import {
  getAvailableStock,
  totalSales,
  totalExpenses,
} from "../lib/crackersBackend";

export default function HomeScreen({ navigation }: any) {
  const [stock, setStock] = useState<number | null>(null);
  const [salesTotal, setSalesTotal] = useState<number>(0);
  const [expensesTotal, setExpensesTotal] = useState<number>(0);

  useEffect(() => {
    refresh();
  }, []);

  async function refresh() {
    try {
      const s = await getAvailableStock();
      setStock(s);
    } catch (e) {
      setStock(null);
    }
    try {
      const t = await totalSales();
      setSalesTotal(t);
    } catch (e) {
      setSalesTotal(0);
    }
    try {
      const ex = await totalExpenses();
      setExpensesTotal(ex);
    } catch (e) {
      setExpensesTotal(0);
    }
  }

  return (
    <SafeAreaView style={styles.safeArea} edges={["top"]}>
      <ScrollView contentContainerStyle={styles.container}>
        <Text style={styles.header} accessible accessibilityRole="header">
          BEMACHO Crackers Dashboard
        </Text>

        <Card leftAccent={theme.colors.primary}>
          <Text style={styles.cardTitle}>Stock</Text>
          <Text style={styles.bigNumber}>
            {stock == null ? "—" : String(stock)}
          </Text>
          <Button
            title="Manage Stock"
            onPress={() => navigation.navigate("Inventory")}
            style={{ marginTop: theme.spacing.sm }}
          />
        </Card>

        <Card leftAccent={theme.colors.accent}>
          <Text style={styles.cardTitle}>Sales</Text>
          <Text style={[styles.bigNumber, { color: theme.colors.primary }]}>
            {theme.currency.symbol}
            {Number(salesTotal).toLocaleString()}
          </Text>
          <Button
            title="Record Sale"
            variant="secondary"
            onPress={() => navigation.navigate("Sales")}
            style={{ marginTop: theme.spacing.sm }}
          />
        </Card>

        <Card leftAccent={theme.colors.primaryDark}>
          <Text style={styles.cardTitle}>Expenses</Text>
          <Text style={[styles.bigNumber, { color: theme.colors.danger }]}>
            {theme.currency.symbol}
            {Number(expensesTotal).toLocaleString()}
          </Text>
          <Button
            title="Add Expense"
            onPress={() => navigation.navigate("Expenses")}
            style={{ marginTop: theme.spacing.sm }}
          />
        </Card>

        <Button
          title="View Reports"
          onPress={() => navigation.navigate("Reports")}
          style={{ marginTop: theme.spacing.lg, alignSelf: "stretch" }}
        />
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: { flex: 1, backgroundColor: theme.colors.background },
  container: {
    padding: theme.spacing.md,
    paddingTop: theme.spacing.lg + layout.secondElementOffset, // bring second element slightly higher
  },
  header: {
    fontSize: theme.type.h1,
    color: theme.colors.primaryDark,
    // center the header with sans-serif
    fontFamily: theme.fonts.heading,
    marginBottom: theme.spacing.lg,
    textAlign: "center",
  },
  cardTitle: {
    fontSize: theme.type.h3,
    color: theme.colors.textPrimary,
    fontFamily: theme.fonts.heading,
  },
  bigNumber: {
    fontSize: 34,
    fontWeight: "700",
    color: theme.colors.primaryDark,
    marginTop: theme.spacing.sm,
    fontFamily: theme.fonts.body,
  },
});
