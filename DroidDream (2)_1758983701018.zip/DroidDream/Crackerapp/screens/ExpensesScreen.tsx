// new file screens/ExpensesScreen.tsx
import React, { useEffect, useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  TouchableOpacity,
  Modal,
  TextInput,
  Button,
  Alert,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import {
  listExpenses,
  addExpense,
  editExpense,
  deleteExpense,
  listExpenseTypes,
} from "../lib/crackersBackend";

export default function ExpensesScreen() {
  const [expenses, setExpenses] = useState<any[]>([]);
  const [types, setTypes] = useState<any[]>([]);
  const [visible, setVisible] = useState(false);
  const [editing, setEditing] = useState<any | null>(null);
  const [typeId, setTypeId] = useState<number | null>(null);
  const [amount, setAmount] = useState("");
  const [note, setNote] = useState("");

  useEffect(() => {
    refresh();
  }, []);

  async function refresh() {
    try {
      const e = await listExpenses();
      setExpenses(e);
    } catch (err) {
      setExpenses([]);
    }
    try {
      const t = await listExpenseTypes();
      setTypes(t);
      if (t.length > 0) setTypeId(t[0].id);
    } catch (err) {
      setTypes([]);
    }
  }

  function openNew() {
    setEditing(null);
    setAmount("");
    setNote("");
    setVisible(true);
  }

  async function onSave() {
    const a = Number(amount);
    if (!typeId) {
      Alert.alert("Error", "Select expense type");
      return;
    }
    if (isNaN(a) || a < 0) {
      Alert.alert("Error", "Enter valid amount");
      return;
    }
    let res;
    if (editing) {
      res = await editExpense({
        id: editing.id,
        expenseTypeId: typeId,
        amount: a,
        date: new Date().toISOString(),
        note,
      });
    } else {
      res = await addExpense({
        expenseTypeId: typeId,
        amount: a,
        date: new Date().toISOString(),
        note,
      });
    }
    if (!res.success) Alert.alert("Error", res.message || "Failed");
    else {
      Alert.alert("Saved", res.message || "Saved");
      setVisible(false);
      refresh();
    }
  }

  async function onDelete(item: any) {
    Alert.alert("Confirm", "Delete this expense?", [
      { text: "Cancel", style: "cancel" },
      {
        text: "Delete",
        style: "destructive",
        onPress: async () => {
          const r = await deleteExpense(item.id);
          if (r.success) {
            Alert.alert("Deleted", r.message || "Deleted");
            refresh();
          } else Alert.alert("Error", r.message || "Failed");
        },
      },
    ]);
  }

  async function onEdit(item: any) {
    setEditing(item);
    setTypeId(item.expense_type_id);
    setAmount(String(item.amount));
    setNote(item.note || "");
    setVisible(true);
  }

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>Expenses</Text>
      </View>
      <View style={styles.content}>
        <TouchableOpacity style={styles.addBtn} onPress={openNew}>
          <Text style={styles.addBtnText}>Add Expense</Text>
        </TouchableOpacity>
        <FlatList
          data={expenses}
          keyExtractor={(i) => String(i.id)}
          renderItem={({ item }) => (
            <View style={styles.row}>
              <View>
                <Text style={styles.rowText}>
                  {item.expense_type} — {item.amount} ZMW
                </Text>
                <Text style={styles.rowSub}>
                  {(item.date || "").slice(0, 10)} • {item.note || ""}
                </Text>
              </View>
              <View style={{ flexDirection: "row", gap: 8 }}>
                <Button title="Edit" onPress={() => onEdit(item)} />
                <Button
                  title="Delete"
                  color="#e53e3e"
                  onPress={() => onDelete(item)}
                />
              </View>
            </View>
          )}
        />
      </View>

      <Modal visible={visible} animationType="slide">
        <SafeAreaView style={styles.modal}>
          <Text style={styles.modalTitle}>
            {editing ? "Edit Expense" : "Add Expense"}
          </Text>
          <Text style={{ marginBottom: 6 }}>Type:</Text>
          <View style={{ flexDirection: "row", marginBottom: 12 }}>
            <FlatList
              horizontal
              data={types}
              keyExtractor={(t) => String(t.id)}
              renderItem={({ item }) => (
                <TouchableOpacity
                  style={[
                    styles.chip,
                    typeId === item.id && { backgroundColor: "#2b6cb0" },
                  ]}
                  onPress={() => setTypeId(item.id)}
                >
                  <Text
                    style={{ color: typeId === item.id ? "white" : "#333" }}
                  >
                    {item.name}
                  </Text>
                </TouchableOpacity>
              )}
            />
          </View>
          <TextInput
            placeholder="Amount (ZMW)"
            keyboardType="decimal-pad"
            style={styles.input}
            value={amount}
            onChangeText={setAmount}
          />
          <TextInput
            placeholder="Note"
            style={styles.input}
            value={note}
            onChangeText={setNote}
          />
          <View style={{ flexDirection: "row", gap: 12 }}>
            <Button title="Cancel" onPress={() => setVisible(false)} />
            <Button title="Save" onPress={onSave} />
          </View>
        </SafeAreaView>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: { padding: 16, borderBottomColor: "#eee", borderBottomWidth: 1 },
  title: { fontSize: 20, fontWeight: "700" },
  content: { padding: 16 },
  addBtn: {
    backgroundColor: "#2b6cb0",
    padding: 12,
    borderRadius: 8,
    alignItems: "center",
    marginBottom: 12,
  },
  addBtnText: { color: "white", fontWeight: "700" },
  row: {
    padding: 12,
    backgroundColor: "white",
    borderRadius: 8,
    marginBottom: 8,
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },
  rowText: { fontWeight: "600" },
  rowSub: { color: "#666", marginTop: 4 },
  modal: { flex: 1, padding: 16 },
  modalTitle: { fontSize: 18, fontWeight: "700", marginBottom: 12 },
  input: {
    borderWidth: 1,
    borderColor: "#ddd",
    padding: 12,
    borderRadius: 8,
    marginBottom: 12,
  },
  chip: {
    padding: 8,
    borderRadius: 16,
    borderWidth: 1,
    borderColor: "#ddd",
    marginRight: 8,
  },
});
