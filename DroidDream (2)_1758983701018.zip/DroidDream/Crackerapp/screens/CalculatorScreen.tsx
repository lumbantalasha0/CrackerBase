// new file screens/CalculatorScreen.tsx
import React, { useEffect, useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  TextInput,
  Button,
  Alert,
  ScrollView,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import {
  calculateIngredients,
  getIngredientUnits,
} from "../lib/crackersBackend";

export default function CalculatorScreen() {
  const [kg, setKg] = useState("");
  const [result, setResult] = useState<any | null>(null);
  const [units, setUnits] = useState<any>({});

  useEffect(() => {
    loadUnits();
  }, []);
  async function loadUnits() {
    const u = await getIngredientUnits();
    setUnits(u);
  }

  async function onCompute() {
    const k = Number(kg);
    if (!k || k <= 0) {
      Alert.alert("Error", "Enter valid kg of flour");
      return;
    }
    const r = await calculateIngredients(k);
    if (!r.success) Alert.alert("Error", r.message || "Failed");
    else {
      setResult(r);
    }
  }

  return (
    <SafeAreaView style={styles.container} edges={["top"]}>
      <View style={styles.header}>
        <Text style={styles.title}>Ingredients Calculator</Text>
      </View>
      <ScrollView contentContainerStyle={styles.content}>
        <Text>Multipliers (per 1kg flour):</Text>
        {Object.keys(units).map((k) => (
          <Text key={k} style={{ marginTop: 4 }}>
            {k}: {units[k]}
          </Text>
        ))}
        <TextInput
          placeholder="Kg of flour"
          keyboardType="decimal-pad"
          style={styles.input}
          value={kg}
          onChangeText={setKg}
        />
        <Button title="Compute" onPress={onCompute} />
        {result && (
          <View style={{ marginTop: 16 }}>
            <Text style={{ fontWeight: "700" }}>
              For {result.flourKg} kg flour:
            </Text>
            {Object.keys(result.ingredients).map((k) => (
              <Text key={k}>
                {k}: {result.ingredients[k]}
              </Text>
            ))}
          </View>
        )}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: "#FFF8E7" },
  header: { padding: 10, borderBottomColor: "#eee", borderBottomWidth: 1 },
  title: { fontSize: 20, fontWeight: "700" },
  content: { padding: 12, paddingBottom: 40 },
  input: {
    borderWidth: 1,
    borderColor: "#ddd",
    padding: 12,
    borderRadius: 8,
    marginVertical: 12,
  },
});
