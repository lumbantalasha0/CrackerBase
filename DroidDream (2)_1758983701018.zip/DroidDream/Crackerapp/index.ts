import { registerRootComponent } from 'expo';
import App from './app';

// Register the main component
registerRootComponent(App);