// new file: lib/api.ts
import { Alert } from "react-native";

let FileSystem: any = null;
try {
  FileSystem = require("expo-file-system");
} catch (e) {
  FileSystem = null;
}

const DEFAULT_ENDPOINT = "https://your-send-report.example.com/send-report";

export async function uploadPdfToServer(
  localUri: string,
  toEmail: string,
  serverUrl?: string,
) {
  const endpoint = serverUrl || DEFAULT_ENDPOINT;
  if (!FileSystem) {
    return { success: false, message: "FileSystem not available" };
  }
  try {
    const base64 = await FileSystem.readAsStringAsync(localUri, {
      encoding: FileSystem.EncodingType.Base64,
    });
    const body = {
      to: toEmail,
      subject: "BEMACHO Crackers Report",
      body: "Auto-uploaded report",
      filename: localUri.split("/").pop(),
      pdfBase64: base64,
    };
    const res = await fetch(endpoint, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    });
    const json = await res.json();
    return json;
  } catch (err) {
    return { success: false, message: String(err) };
  }
}

export default { uploadPdfToServer };
