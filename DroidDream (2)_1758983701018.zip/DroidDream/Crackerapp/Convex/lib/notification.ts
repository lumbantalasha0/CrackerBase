// new file: lib/notifications.ts
let Notifications: any = null;
try {
  Notifications = require("expo-notifications");
} catch (e) {
  Notifications = null;
}

export async function requestPermissions() {
  if (!Notifications)
    return { granted: false, message: "Notifications not available" };
  try {
    const settings = await Notifications.requestPermissionsAsync();
    return settings;
  } catch (e) {
    return { granted: false, message: String(e) };
  }
}

export async function scheduleDailySummary(hour = 9, minute = 0) {
  if (!Notifications)
    return { success: false, message: "Notifications not available" };
  try {
    // cancel existing
    await Notifications.cancelAllScheduledNotificationsAsync();
    const trigger = { hour, minute, repeats: true };
    const id = await Notifications.scheduleNotificationAsync({
      content: {
        title: "BEMACHO Daily Summary",
        body: "Tap to view today's sales and stock summary",
      },
      trigger,
    });
    return { success: true, id };
  } catch (e) {
    return { success: false, message: String(e) };
  }
}

export async function cancelScheduledSummaries() {
  if (!Notifications)
    return { success: false, message: "Notifications not available" };
  try {
    await Notifications.cancelAllScheduledNotificationsAsync();
    return { success: true };
  } catch (e) {
    return { success: false, message: String(e) };
  }
}

export default {
  requestPermissions,
  scheduleDailySummary,
  cancelScheduledSummaries,
};
