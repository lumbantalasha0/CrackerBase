export const spacing = {
  xs: 6,
  sm: 8,
  md: 16,
  lg: 24,
  xl: 32,
};

export const radii = {
  sm: 8,
  md: 12,
  lg: 16,
};

export const type = {
  h1: 28,
  h2: 22,
  h3: 18,
  body: 16,
  small: 13,
};

export const fonts = {
  // Use system sans-serif for heading and body to ensure consistent sans-serif appearance
  heading: "System",
  body: "System",
  mono: "RobotoMono, monospace",
};

export const colors = {
  // Wheat / Gold theme
  primary: "#C49A6C", // Wheat/Golden brown
  primaryDark: "#8B5E3C",
  accent: "#FFD700",
  background: "#FFF8E7",
  surface: "#FFFFFF",
  surfaceAlt: "#FFFCEB",
  border: "#E9DCC8",
  textPrimary: "#3B2F2F",
  textSecondary: "#6B4F4F",
  success: "#4CAF50",
  danger: "#D32F2F",
  muted: "#A1866A",
};

export const currency = {
  code: "ZMW",
  symbol: "ZMW ",
};

const theme = {
  spacing,
  radii,
  type,
  fonts,
  colors,
  currency,
};

export default theme;
