export const layout = {
  // Small offset used to bring the second major element closer to the header
  secondElementOffset: 8,
};

export default layout;
