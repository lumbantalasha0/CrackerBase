// lib/db.ts
// Robust AsyncStorage-backed DB layer with dynamic require of AsyncStorage.
// Provides: products (Crackers-only), stock entries, sales (CRUD), expenses (CRUD), customers (CRUD),
// calculator units & results, basic reports, and safe in-memory fallback when AsyncStorage is unavailable.

import {
  ProductRow,
  StockEntryRow,
  SaleRow,
  ExpenseRow,
  CustomerRow,
  CalculatorUnit,
  CalculatorResult,
} from "../types";

const STORAGE_KEY = "crackers_storage_v1";
let AsyncStorage: any = null;
let asyncStorageAvailable = true;

// Schema for the in-memory/AsyncStorage store
type StoreSchema = {
  meta: {
    productId: number;
    stockEntryId: number;
    saleId: number;
    expenseId: number;
    customerId: number;
    calcUnitId: number;
    calcResultId: number;
    expenseTypeId: number;
    ingredientMultiplierId: number;
  };
  products: Array<{ id: number; name: string; threshold: number }>;
  stock_entries: Array<{
    id: number;
    product_id: number;
    qty: number;
    supplier?: string | null;
    date: string;
  }>;
  sales: Array<{
    id: number;
    product_id: number;
    qty: number;
    price: number;
    buyerId?: number | null;
    buyerName?: string | null;
    date: string;
  }>;
  expenses: Array<{
    id: number;
    category: string;
    amount: number;
    date: string;
    notes?: string | null;
  }>;
  settings: Record<string, string>;
  customers: Array<{
    id: number;
    name: string;
    phone?: string | null;
    businessName?: string | null;
    location?: string | null;
  }>;
  calculator_units: Array<{
    id: number;
    ingredient: string;
    unitName: string;
    unitValue: number;
  }>;
  calculator_results: Array<{
    id: number;
    title?: string | null;
    result: number;
    details?: Record<string, number> | null;
    date: string;
  }>;
  expense_types: Array<{ id: number; name: string }>;
  ingredient_multipliers: Array<{
    id: number;
    ingredient: string;
    perKg: number;
  }>;
};

const DEFAULT_STORE: StoreSchema = {
  meta: {
    productId: 1,
    stockEntryId: 1,
    saleId: 1,
    expenseId: 1,
    customerId: 1,
    calcUnitId: 1,
    calcResultId: 1,
    expenseTypeId: 1,
    ingredientMultiplierId: 1,
  },
  products: [],
  stock_entries: [],
  sales: [],
  expenses: [],
  settings: {},
  customers: [],
  calculator_units: [],
  calculator_results: [],
  expense_types: [],
  ingredient_multipliers: [],
};

let storeCache: StoreSchema | null = null;

async function ensureAsyncStorage(): Promise<boolean> {
  if (AsyncStorage) return true;
  if (!asyncStorageAvailable) return false;
  try {
    // Load dynamically to avoid import-time crashes in snack/web environments
    // eslint-disable-next-line @typescript-eslint/no-var-requires
    const mod = require("@react-native-async-storage/async-storage");
    const candidate =
      mod && (typeof mod.getItem === "function" ? mod : mod.default || mod);
    if (candidate && typeof candidate.getItem === "function") {
      AsyncStorage = candidate;
      return true;
    }
    asyncStorageAvailable = false;
    return false;
  } catch (err) {
    asyncStorageAvailable = false;
    return false;
  }
}

function deepClone<T>(v: T): T {
  return JSON.parse(JSON.stringify(v));
}

async function loadStore(): Promise<StoreSchema> {
  if (storeCache) return storeCache;
  const ok = await ensureAsyncStorage();
  if (!ok) {
    storeCache = deepClone(DEFAULT_STORE);
    return storeCache;
  }

  try {
    const raw = await AsyncStorage.getItem(STORAGE_KEY);
    if (!raw) {
      storeCache = deepClone(DEFAULT_STORE);
      await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(storeCache));
      return storeCache;
    }
    storeCache = JSON.parse(raw) as StoreSchema;
    // ensure meta exists
    if (!storeCache.meta) storeCache.meta = deepClone(DEFAULT_STORE.meta);
    if (!Array.isArray(storeCache.products)) storeCache.products = [];
    if (!Array.isArray(storeCache.stock_entries)) storeCache.stock_entries = [];
    if (!Array.isArray(storeCache.sales)) storeCache.sales = [];
    if (!Array.isArray(storeCache.expenses)) storeCache.expenses = [];
    if (!Array.isArray(storeCache.customers)) storeCache.customers = [];
    if (!Array.isArray(storeCache.calculator_units))
      storeCache.calculator_units = [];
    if (!Array.isArray(storeCache.calculator_results))
      storeCache.calculator_results = [];
    if (!Array.isArray(storeCache.expense_types)) storeCache.expense_types = [];
    if (!Array.isArray(storeCache.ingredient_multipliers))
      storeCache.ingredient_multipliers = [];
    if (!storeCache.settings) storeCache.settings = {};
    return storeCache;
  } catch (err) {
    asyncStorageAvailable = false;
    storeCache = deepClone(DEFAULT_STORE);
    return storeCache;
  }
}

async function saveStore(): Promise<void> {
  if (!storeCache) return;
  if (!asyncStorageAvailable) return; // keep it in memory only
  const ok = await ensureAsyncStorage();
  if (!ok) return;
  try {
    await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(storeCache));
  } catch (err) {
    asyncStorageAvailable = false;
  }
}

// ---------- Helpers ----------
function normalizeCrackersName(name?: string) {
  // We only track "Crackers" product. Normalize any input to "Crackers".
  // If name contains the word 'cracker' (case-insensitive) we accept; otherwise we still use 'Crackers'.
  if (!name) return "Crackers";
  const n = name.trim().toLowerCase();
  if (n.includes("cracker")) return "Crackers";
  return "Crackers";
}

function withinRange(dateIso: string, startIso?: string, endIso?: string) {
  if (!startIso && !endIso) return true;
  const d = new Date(dateIso).getTime();
  if (startIso) {
    const s = new Date(startIso).getTime();
    if (d < s) return false;
  }
  if (endIso) {
    const e = new Date(endIso).getTime();
    if (d > e) return false;
  }
  return true;
}

// ---------- Public API ----------
export async function initDB(): Promise<void> {
  const store = await loadStore();
  // Ensure a single 'Crackers' product exists
  const existing = store.products.find(
    (p) => p.name.toLowerCase() === "crackers",
  );
  if (!existing) {
    const id = store.meta.productId++;
    store.products.push({ id, name: "Crackers", threshold: 5 });
    await saveStore();
  }
}

export async function setSetting(key: string, value: string): Promise<void> {
  const store = await loadStore();
  store.settings[key] = value;
  await saveStore();
}

export async function getSetting(key: string): Promise<string | null> {
  const store = await loadStore();
  return store.settings[key] ?? null;
}

export async function addProductIfNotExists(
  name: string,
  threshold = 0,
): Promise<number> {
  // We only allow a single product: 'Crackers'. Always return that product's id.
  const store = await loadStore();
  const normalized = normalizeCrackersName(name);
  let p = store.products.find(
    (p) => p.name.toLowerCase() === normalized.toLowerCase(),
  );
  if (p) {
    if (threshold && p.threshold !== threshold) {
      p.threshold = threshold;
      await saveStore();
    }
    return p.id;
  }
  const id = store.meta.productId++;
  const product = { id, name: normalized, threshold };
  store.products.push(product);
  await saveStore();
  return id;
}

export async function getProductsWithBalance(): Promise<ProductRow[]> {
  const store = await loadStore();
  const out: ProductRow[] = store.products.map((p) => {
    const total_in = store.stock_entries
      .filter((se) => se.product_id === p.id)
      .reduce((s, e) => s + Number(e.qty), 0);
    const total_out = store.sales
      .filter((sale) => sale.product_id === p.id)
      .reduce((s, e) => s + Number(e.qty), 0);
    const balance = total_in - total_out;
    return {
      id: p.id,
      name: p.name,
      threshold: p.threshold,
      total_in,
      total_out,
      balance,
    };
  });
  out.sort((a, b) => a.name.toLowerCase().localeCompare(b.name.toLowerCase()));
  return out;
}

export async function getLowStockProducts(): Promise<ProductRow[]> {
  const products = await getProductsWithBalance();
  return products.filter((p) => (p.balance ?? 0) <= (p.threshold ?? 0));
}

export async function addStockEntry(
  product_id: number,
  qty: number,
  supplier?: string,
  date?: string,
): Promise<number> {
  const d = date ?? new Date().toISOString();
  const store = await loadStore();
  const id = store.meta.stockEntryId++;
  store.stock_entries.push({
    id,
    product_id,
    qty,
    supplier: supplier ?? null,
    date: d,
  });
  await saveStore();
  return id;
}

export async function recordSale(
  product_id: number,
  qty: number,
  price: number,
  buyerId?: number,
  buyerName?: string,
  date?: string,
): Promise<number> {
  const d = date ?? new Date().toISOString();
  const store = await loadStore();
  const id = store.meta.saleId++;
  store.sales.push({
    id,
    product_id,
    qty,
    price,
    buyerId: buyerId ?? null,
    buyerName: buyerName ?? null,
    date: d,
  });
  await saveStore();
  return id;
}

export async function updateSale(
  id: number,
  fields: Partial<{
    qty: number;
    price: number;
    buyerId?: number | null;
    buyerName?: string | null;
    date?: string;
  }>,
): Promise<void> {
  const store = await loadStore();
  const idx = store.sales.findIndex((s) => s.id === id);
  if (idx === -1) throw new Error("Sale not found");
  const sale = store.sales[idx];
  store.sales[idx] = { ...sale, ...fields } as any;
  await saveStore();
}

export async function deleteSale(id: number): Promise<void> {
  const store = await loadStore();
  const before = store.sales.length;
  store.sales = store.sales.filter((s) => s.id !== id);
  if (store.sales.length !== before) await saveStore();
}

export async function addExpense(
  category: string,
  amount: number,
  date?: string,
  notes?: string,
): Promise<number> {
  const d = date ?? new Date().toISOString();
  const store = await loadStore();
  const id = store.meta.expenseId++;
  store.expenses.push({ id, category, amount, date: d, notes: notes ?? null });
  await saveStore();
  return id;
}

export async function updateExpense(
  id: number,
  fields: Partial<{
    category: string;
    amount: number;
    date?: string;
    notes?: string;
  }>,
): Promise<void> {
  const store = await loadStore();
  const idx = store.expenses.findIndex((e) => e.id === id);
  if (idx === -1) throw new Error("Expense not found");
  store.expenses[idx] = { ...store.expenses[idx], ...fields };
  await saveStore();
}

export async function deleteExpense(id: number): Promise<void> {
  const store = await loadStore();
  const before = store.expenses.length;
  store.expenses = store.expenses.filter((e) => e.id !== id);
  if (store.expenses.length !== before) await saveStore();
}

export async function getSales(): Promise<SaleRow[]> {
  const store = await loadStore();
  const out: SaleRow[] = store.sales
    .slice()
    .sort((a, b) => (b.date || "").localeCompare(a.date || ""))
    .map((s) => {
      const productName = store.products.find(
        (p) => p.id === s.product_id,
      )?.name;
      const customerName = s.buyerId
        ? store.customers.find((c) => c.id === s.buyerId)?.name
        : s.buyerName;
      return {
        id: s.id,
        product_id: s.product_id,
        qty: s.qty,
        price: s.price,
        buyerId: s.buyerId ?? undefined,
        buyerName: s.buyerName ?? undefined,
        date: s.date,
        productName,
        customerName: customerName ?? undefined,
      };
    });
  return out;
}

export async function getExpenses(): Promise<ExpenseRow[]> {
  const store = await loadStore();
  return store.expenses
    .slice()
    .sort((a, b) => (b.date || "").localeCompare(a.date || ""));
}

// ---------- Customers ----------
export async function addCustomer(
  name: string,
  phone?: string,
  businessName?: string,
  location?: string,
): Promise<number> {
  const store = await loadStore();
  const id = store.meta.customerId++;
  store.customers.push({
    id,
    name: name.trim(),
    phone: phone ?? null,
    businessName: businessName ?? null,
    location: location ?? null,
  });
  await saveStore();
  return id;
}

export async function updateCustomer(
  id: number,
  fields: Partial<{
    name: string;
    phone?: string | null;
    businessName?: string | null;
    location?: string | null;
  }>,
): Promise<void> {
  const store = await loadStore();
  const idx = store.customers.findIndex((c) => c.id === id);
  if (idx === -1) throw new Error("Customer not found");
  store.customers[idx] = { ...store.customers[idx], ...fields } as any;
  await saveStore();
}

export async function deleteCustomer(id: number): Promise<void> {
  const store = await loadStore();
  store.customers = store.customers.filter((c) => c.id !== id);
  await saveStore();
}

export async function getCustomers(): Promise<CustomerRow[]> {
  const store = await loadStore();
  return store.customers
    .slice()
    .map((c) => ({
      id: c.id,
      name: c.name,
      phone: c.phone ?? undefined,
      businessName: c.businessName ?? undefined,
      location: c.location ?? undefined,
    }));
}

// ---------- Calculator units & results ----------
export async function addCalculatorUnit(
  ingredient: string,
  unitName: string,
  unitValue: number,
): Promise<number> {
  const store = await loadStore();
  const id = store.meta.calcUnitId++;
  store.calculator_units.push({
    id,
    ingredient: ingredient.trim(),
    unitName: unitName.trim(),
    unitValue,
  });
  await saveStore();
  return id;
}

export async function updateCalculatorUnit(
  id: number,
  fields: Partial<{ ingredient: string; unitName: string; unitValue: number }>,
): Promise<void> {
  const store = await loadStore();
  const idx = store.calculator_units.findIndex((u) => u.id === id);
  if (idx === -1) throw new Error("Calculator unit not found");
  store.calculator_units[idx] = {
    ...store.calculator_units[idx],
    ...fields,
  } as any;
  await saveStore();
}

export async function deleteCalculatorUnit(id: number): Promise<void> {
  const store = await loadStore();
  store.calculator_units = store.calculator_units.filter((u) => u.id !== id);
  await saveStore();
}

export async function getCalculatorUnits(): Promise<CalculatorUnit[]> {
  const store = await loadStore();
  return store.calculator_units
    .slice()
    .map((u) => ({
      ingredient: u.ingredient,
      unitName: u.unitName,
      unitValue: u.unitValue,
    }));
}

export async function saveCalculatorResult(
  result: number,
  details?: Record<string, number>,
  title?: string,
): Promise<number> {
  const d = new Date().toISOString();
  const store = await loadStore();
  const id = store.meta.calcResultId++;
  store.calculator_results.push({
    id,
    title: title ?? null,
    result,
    details: details ?? null,
    date: d,
  });
  await saveStore();
  return id;
}

export async function getCalculatorResults(): Promise<CalculatorResult[]> {
  const store = await loadStore();
  return store.calculator_results
    .slice()
    .sort((a, b) => (b.date || "").localeCompare(a.date || ""))
    .map((r) => ({
      id: r.id,
      title: r.title ?? undefined,
      result: r.result,
      details: r.details ?? undefined,
      date: r.date,
    }));
}

// ---------- Expense types ----------
export async function addExpenseType(name: string): Promise<number> {
  const store = await loadStore();
  const id = store.meta.expenseTypeId++;
  store.expense_types.push({ id, name: name.trim() });
  await saveStore();
  return id;
}

export async function updateExpenseType(
  id: number,
  name: string,
): Promise<void> {
  const store = await loadStore();
  const idx = store.expense_types.findIndex((e) => e.id === id);
  if (idx === -1) throw new Error("Expense type not found");
  store.expense_types[idx].name = name.trim();
  await saveStore();
}

export async function deleteExpenseType(id: number): Promise<void> {
  const store = await loadStore();
  store.expense_types = store.expense_types.filter((e) => e.id !== id);
  await saveStore();
}

export async function getExpenseTypes(): Promise<
  Array<{ id: number; name: string }>
> {
  const store = await loadStore();
  return store.expense_types.slice();
}

// ---------- Ingredient multipliers (per kg of flour) ----------
export async function addIngredientMultiplier(
  ingredient: string,
  perKg: number,
): Promise<number> {
  const store = await loadStore();
  const id = store.meta.ingredientMultiplierId++;
  store.ingredient_multipliers.push({
    id,
    ingredient: ingredient.trim(),
    perKg,
  });
  await saveStore();
  return id;
}

export async function updateIngredientMultiplier(
  id: number,
  fields: Partial<{ ingredient: string; perKg: number }>,
): Promise<void> {
  const store = await loadStore();
  const idx = store.ingredient_multipliers.findIndex((i) => i.id === id);
  if (idx === -1) throw new Error("Ingredient multiplier not found");
  store.ingredient_multipliers[idx] = {
    ...store.ingredient_multipliers[idx],
    ...fields,
  } as any;
  await saveStore();
}

export async function deleteIngredientMultiplier(id: number): Promise<void> {
  const store = await loadStore();
  store.ingredient_multipliers = store.ingredient_multipliers.filter(
    (i) => i.id !== id,
  );
  await saveStore();
}

export async function getIngredientMultipliers(): Promise<
  Array<{ id: number; ingredient: string; perKg: number }>
> {
  const store = await loadStore();
  return store.ingredient_multipliers.slice();
}

// ---------- Export all data ----------
export async function exportAllData(): Promise<any> {
  const store = await loadStore();
  return {
    products: store.products.slice(),
    stock_entries: store.stock_entries.slice(),
    sales: store.sales.slice(),
    expenses: store.expenses.slice(),
    customers: store.customers.slice(),
    calculator_units: store.calculator_units.slice(),
    calculator_results: store.calculator_results.slice(),
    expense_types: store.expense_types.slice(),
    ingredient_multipliers: store.ingredient_multipliers.slice(),
    settings: { ...store.settings },
  };
}

// ---------- Reports & analytics ----------
export async function getReport(startDateIso?: string, endDateIso?: string) {
  const store = await loadStore();
  const sales = store.sales.filter((s) =>
    withinRange(s.date, startDateIso, endDateIso),
  );
  const expenses = store.expenses.filter((e) =>
    withinRange(e.date, startDateIso, endDateIso),
  );

  const totalSalesValue = sales.reduce(
    (s, x) => s + Number(x.qty) * Number(x.price),
    0,
  );
  const totalCrackersSold = sales.reduce((s, x) => s + Number(x.qty), 0);
  const totalExpenses = expenses.reduce((s, x) => s + Number(x.amount), 0);
  const profit = totalSalesValue - totalExpenses;

  // Top customers by quantity
  const customerMap: Record<
    string,
    { id?: number; name: string; qty: number; total: number; orders: number }
  > = {};
  for (const s of sales) {
    const key = s.buyerId
      ? `id_${s.buyerId}`
      : `name_${(s.buyerName || "Walk-in").trim()}`;
    if (!customerMap[key]) {
      const name = s.buyerId
        ? (store.customers.find((c) => c.id === s.buyerId)?.name ??
          s.buyerName ??
          "Unknown")
        : (s.buyerName ?? "Walk-in");
      customerMap[key] = {
        id: s.buyerId ?? undefined,
        name,
        qty: 0,
        total: 0,
        orders: 0,
      };
    }
    customerMap[key].qty += Number(s.qty);
    customerMap[key].total += Number(s.qty) * Number(s.price);
    customerMap[key].orders += 1;
  }
  const topCustomers = Object.values(customerMap)
    .sort((a, b) => b.qty - a.qty)
    .slice(0, 5);

  return {
    totalSalesValue,
    totalCrackersSold,
    totalExpenses,
    profit,
    topCustomers,
    salesCount: sales.length,
    expenseCount: expenses.length,
  };
}

// Utility exports for testing/consistency
export async function clearAllData(): Promise<void> {
  storeCache = deepClone(DEFAULT_STORE);
  await saveStore();
}

// Default export containing all functions
export default {
  initDB,
  setSetting,
  getSetting,
  addProductIfNotExists,
  addStockEntry,
  recordSale,
  updateSale,
  deleteSale,
  addExpense,
  updateExpense,
  deleteExpense,
  getProductsWithBalance,
  getSales,
  getExpenses,
  getLowStockProducts,
  addCustomer,
  updateCustomer,
  deleteCustomer,
  getCustomers,
  addCalculatorUnit,
  updateCalculatorUnit,
  deleteCalculatorUnit,
  getCalculatorUnits,
  saveCalculatorResult,
  getCalculatorResults,
  getReport,
  addExpenseType,
  updateExpenseType,
  deleteExpenseType,
  getExpenseTypes,
  addIngredientMultiplier,
  updateIngredientMultiplier,
  deleteIngredientMultiplier,
  getIngredientMultipliers,
  exportAllData,
  clearAllData,
};
