import React, { useEffect, useState, useRef } from 'react';
import {
  ActivityIndicator,
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Animated,
  Dimensions,
  Pressable,
} from 'react-native';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { MaterialIcons } from '@expo/vector-icons';

import HomeScreen from './screens/HomeScreen';
import InventoryScreen from './screens/InventoryScreen';
import SalesScreen from './screens/SalesScreen';
import ExpensesScreen from './screens/ExpensesScreen';
import CalculatorScreen from './screens/CalculatorScreen';
import ReportsScreen from './screens/ReportsScreen';
import SettingsScreen from './screens/SettingsScreen';

import { initDB, quickHealthCheck } from './lib/crackersBackend';
import theme from './lib/theme';
import { ToastProvider } from './components/Toast';
import notifications from './lib/notifications';

const SCREENS = [
  { key: 'Home', label: 'Home', icon: 'home' },
  { key: 'Inventory', label: 'Stock', icon: 'inventory' },
  { key: 'Sales', label: 'Sales', icon: 'attach-money' },
  { key: 'Expenses', label: 'Expenses', icon: 'receipt' },
  { key: 'Calculator', label: 'Calculator', icon: 'calculate' },
  { key: 'Reports', label: 'Reports', icon: 'bar-chart' },
  { key: 'Settings', label: 'Settings', icon: 'settings' },
];

const DRAWER_WIDTH = Math.min(300, Dimensions.get('window').width * 0.78);

export default function App() {
  const [loading, setLoading] = useState(true);
  const [active, setActive] = useState('Home');
  const [drawerOpen, setDrawerOpen] = useState(false);
  const anim = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    (async () => {
      try {
        await initDB();
        await quickHealthCheck();
        // request notification permission
        try { await notifications.requestPermissions(); } catch (e) { /* ignore */ }
      } catch (err) {
        console.warn('DB init error', err);
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  useEffect(() => {
    Animated.timing(anim, { toValue: drawerOpen ? 1 : 0, duration: 240, useNativeDriver: true }).start();
  }, [drawerOpen, anim]);

  function openDrawer() { setDrawerOpen(true); }
  function closeDrawer() { setDrawerOpen(false); }
  function toggleDrawer() { setDrawerOpen(v => !v); }

  const translateX = anim.interpolate({ inputRange: [0, 1], outputRange: [-DRAWER_WIDTH, 0] });
  const overlayOpacity = anim.interpolate({ inputRange: [0, 1], outputRange: [0, 0.5] });

  if (loading) {
    return (
      <SafeAreaProvider style={styles.container}>
        <View style={styles.center}>
          <ActivityIndicator size="large" color={theme.colors.primary} />
          <Text style={{ marginTop: 12, color: theme.colors.textSecondary }}>Initializing app...</Text>
        </View>
      </SafeAreaProvider>
    );
  }

  // Lightweight navigation prop passed to screens
  const navigation = {
    navigate: (key: string) => { setActive(key); closeDrawer(); },
    openDrawer: () => openDrawer(),
    closeDrawer: () => closeDrawer(),
  } as const;

  function renderActive() {
    const props = { navigation };
    if (active === 'Home') return <HomeScreen {...props} />;
    if (active === 'Inventory') return <InventoryScreen {...props} />;
    if (active === 'Sales') return <SalesScreen {...props} />;
    if (active === 'Expenses') return <ExpensesScreen {...props} />;
    if (active === 'Calculator') return <CalculatorScreen {...props} />;
    if (active === 'Reports') return <ReportsScreen {...props} />;
    return <SettingsScreen {...props} />;
  }

  return (
    <SafeAreaProvider style={styles.container}>
      <ToastProvider>
        <View style={styles.appContainer}>
          {/* Drawer Overlay */}
          {drawerOpen && (
            <Pressable style={StyleSheet.absoluteFill} onPress={closeDrawer}>
              <Animated.View style={[styles.overlay, { opacity: overlayOpacity }]} />
            </Pressable>
          )}

          {/* Drawer */}
          <Animated.View style={[styles.drawer, { transform: [{ translateX }] }]}>
            <View style={styles.drawerHeader}>
              <Text style={styles.drawerTitle}>BEMACHO</Text>
              <Text style={styles.drawerSubtitle}>Crackers Manager</Text>
            </View>
            <View style={styles.drawerList}>
              {SCREENS.map(s => (
                <TouchableOpacity key={s.key} style={[styles.drawerItem, active === s.key && styles.drawerItemActive]} onPress={() => { setActive(s.key); closeDrawer(); }}>
                  <MaterialIcons name={s.icon as any} size={20} color={active === s.key ? theme.colors.primaryDark : theme.colors.textSecondary} />
                  <Text style={[styles.drawerItemText, active === s.key && { color: theme.colors.primaryDark }]}>{s.label}</Text>
                </TouchableOpacity>
              ))}
            </View>
            <View style={styles.drawerFooter}>
              <Text style={styles.drawerFooterText}>made by Lumba</Text>
            </View>
          </Animated.View>

          {/* Main content area */}
          <View style={styles.main}>
            {/* Header with hamburger - fixed top padding to avoid notch overlap */}
            <View style={[styles.header, { paddingTop: 8 }]}>
              <TouchableOpacity onPress={toggleDrawer} style={styles.hamburger}>
                <MaterialIcons name="menu" size={26} color={theme.colors.primaryDark} />
              </TouchableOpacity>
              <Text style={styles.headerTitle}>{active}</Text>
              <View style={{ width: 48 }} />
            </View>

            <View style={styles.content}>{renderActive()}</View>
          </View>
        </View>
      </ToastProvider>
    </SafeAreaProvider>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  appContainer: { flex: 1, flexDirection: 'row' },
  center: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  drawer: {
    position: 'absolute',
    left: 0,
    top: 0,
    bottom: 0,
    width: DRAWER_WIDTH,
    backgroundColor: theme.colors.surface,
    borderRightWidth: 1,
    borderRightColor: theme.colors.border,
    zIndex: 30,
    paddingTop: 40,
  },
  overlay: { flex: 1, backgroundColor: '#000' },
  drawerHeader: { paddingHorizontal: 16, paddingBottom: 12 },
  drawerTitle: { fontSize: 22, fontFamily: theme.fonts.heading, color: theme.colors.primaryDark, fontWeight: '700' },
  drawerSubtitle: { color: theme.colors.textSecondary },
  drawerList: { marginTop: 8 },
  drawerFooter: { marginTop: 'auto', padding: 16, borderTopWidth: 1, borderTopColor: theme.colors.border },
  drawerFooterText: { color: theme.colors.textSecondary, fontSize: 12 },
  drawerItem: { flexDirection: 'row', alignItems: 'center', paddingVertical: 12, paddingHorizontal: 16, gap: 12 },
  drawerItemActive: { backgroundColor: theme.colors.surfaceAlt },
  drawerItemText: { marginLeft: 12, color: theme.colors.textSecondary, fontSize: 16 },
  main: { flex: 1 },
  header: { height: 68, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 12, borderBottomWidth: 1, borderBottomColor: theme.colors.border, backgroundColor: theme.colors.background },
  hamburger: { width: 48, alignItems: 'flex-start', justifyContent: 'center' },
  headerTitle: { fontSize: 18, fontFamily: theme.fonts.heading, color: theme.colors.primaryDark },
  content: { flex: 1, backgroundColor: theme.colors.background },
});