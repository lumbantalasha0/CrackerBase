# Business Management Mobile App

## Overview

This is a React Native mobile application built with Expo that provides comprehensive business management tools. The app features a tabbed interface with six main modules: Inventory Management, Sales Tracking, Expense Management, Business Calculator, Reports & Analytics, and Settings. Currently in early development stage with basic screen structure and an in-memory database implementation serving as a foundation for future database integration.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React Native with Expo SDK v54
- **Navigation**: Custom tab-based navigation system using state management
- **UI Components**: Native React Native components with Material Icons
- **Screen Structure**: Modular screen components organized in `/screens` directory
- **State Management**: React hooks (useState, useEffect) for local state management
- **Styling**: StyleSheet API with consistent design patterns across screens

### Mobile Platform Support
- **Cross-Platform**: Targets iOS, Android, and Web platforms
- **New Architecture**: Expo's new architecture enabled for better performance
- **Safe Area**: React Native Safe Area Context for proper layout on modern devices
- **Responsive Design**: Adaptive icons and edge-to-edge layout support

### Data Layer
- **Current Implementation**: In-memory JavaScript object database (`crackersBackend.js`)
- **Database Structure**: Separate collections for inventory, sales, expenses, and settings
- **Initialization**: Async database setup with health checks and sample data seeding
- **Future Migration Path**: Architecture designed to easily replace in-memory storage with persistent database

### Application State Management
- **Loading States**: Centralized loading management during database initialization
- **Error Handling**: Try-catch blocks with console warnings for database operations
- **Tab Navigation**: Simple state-based tab switching without external navigation libraries

## External Dependencies

### Core Dependencies
- **Expo SDK (~54.0.10)**: Main development platform and build system
- **React (19.1.0)**: Core JavaScript library for building user interface
- **React Native (0.81.4)**: Mobile app development framework
- **React Native Web (^0.21.0)**: Web platform support for cross-platform deployment

### UI and UX Libraries
- **React Native Safe Area Context (^5.6.1)**: Safe area management for modern devices
- **Expo Vector Icons**: Material Icons integration for consistent iconography
- **Expo Status Bar**: Status bar configuration and styling

### Development Tools
- **Expo CLI**: Development server and build tools
- **Metro Bundler**: JavaScript bundler integrated with React Native
- **Babel**: JavaScript transpilation for modern syntax support

### Platform-Specific Configurations
- **iOS**: Tablet support enabled, adaptive splash screens
- **Android**: Adaptive icons, edge-to-edge display support
- **Web**: Favicon and web-specific optimizations

Note: The current in-memory database implementation is designed as a temporary solution. The architecture supports easy migration to persistent storage solutions like SQLite, PostgreSQL, or cloud-based databases in future iterations.